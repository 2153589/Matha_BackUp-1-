@extends('layouts.app')
@section('title', 'Bookings')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
                <table class="table table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Room No</th>
                    <th>Status</th>
                    <th>Contact</th>
                    <th></th>
                </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
@endsection
