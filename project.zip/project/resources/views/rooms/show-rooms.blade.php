@extends('layouts.app')
@section('title', 'Rooms')
@section('content')
<div class="container text-center">
    <div class="row">
        <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-success"></i>
                Occupied
        </div>
        <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-danger"></i>
                    Vacant
        </div>
        <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-warning"></i>
                    Reserved
        </div>
         <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-dark"></i>
                    Under Rectification
        </div>
    </div>
    <hr>
    <br>
    <div class="row">
            <h5>Harvard</h5>
              <div class="col-md-12">
                    <p>Lower Ground Floor</p>
                    <div class="row">
                    </div>
              </div>
    </div>

</div>

</div>
@endsection


