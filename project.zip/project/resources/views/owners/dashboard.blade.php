@extends('layouts.app')
@section('title', 'Owners')
@section('content')
<div class="container">
     <h4>Owners</h4>
    <div class="input-group md-form form-sm form-1 pl-0">
            <div class="input-group-prepend">
              <span class="input-group-text purple lighten-3" id="basic-text1"><i class="fas fa-search text-white"
                  aria-hidden="true"></i></span>
            </div>
            <form id="search_owner_form" action="/search/users" method="GET"></form>
            <input class="form-control my-0 py-1" type="text" placeholder="Enter owner info..." aria-label="Search" name="owner_info" value="{{ session('owner_info') }}"  form="search_owner_form">
    </div>
    <br>
    <div class="row">
       <div class="col-md-12">

    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped table-hover">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Room No</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        </div>
    </div>
</div>
@endsection
