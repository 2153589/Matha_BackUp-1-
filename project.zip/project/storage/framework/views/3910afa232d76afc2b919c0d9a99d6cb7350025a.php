<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title text-center">Units</h5>
                    
                    <a class="btn btn-primary" href="/rooms"><i class="fas fa-tasks"></i> &nbspManage Units</a>
                </div>
            </div>
        </div>

        <div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title text-center">Tenants</h5>
                    
                    <a class="btn btn-primary" href="/residents"><i class="fas fa-tasks"></i> &nbspManage Tenants</a>
                </div>
            </div>
        </div>

        <div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title text-center">Employees</h5>
                    
                    <a class="btn btn-primary" href="/employees"><i class="fas fa-tasks"></i> &nbspManage Employees</a>
                </div>
            </div>
        </div>

        <div class="col-sm-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title text-center">Unit Owners</h5>
                        
                        <a class="btn btn-primary" href="/owners"><i class="fas fa-tasks"></i> &nbspManage Unit Owners</a>
                    </div>
                </div>
            </div>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12">
            <h4>Dashboard</h4>
            <table class="table table-striped">
                    <tr>
                        <th></th>
                        <td>Occupied</td>
                        <td>Vacant</td>
                        <td>Reserved</td>
                        <td>Rectification</td>
                        <th>Total</th>
                    </tr>

                    <tr>
                        <td>Harvard</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                     <tr>
                        <td>Princeton</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                     <tr>
                        <td>Wharton</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <th>Total</th>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                </table>
        </div>
    </div>
</div>
<hr>
<!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4">

        <!-- Footer Links -->
        <div class="container text-center text-md-left">


          <!-- Grid row -->
          <div class="row d-flex align-items-center">

            <!-- Grid column -->
            <div class="col-md-7 col-lg-8">

              <!--Copyright-->
              <p class="text-center text-md-left">
                <a href="#!">
                  <strong> Martha Management System</strong>
                </a>
              </p>

            </div>
            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-5 col-lg-4 ml-lg-0">


            </div>
            <!-- Grid column -->

          </div>
          <!-- Grid row -->

        </div>
        <!-- Footer Links -->

      </footer>
      <!-- Footer -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mike\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>