<?php $__env->startSection('title', 'Rooms'); ?>
<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <div class="row">
        <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-success"></i>
                Occupied
        </div>
        <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-danger"></i>
                    Vacant
        </div>
        <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-warning"></i>
                    Reserved
        </div>
         <div class="col-md-3">
            <i class="fas fa-home fa-1x btn btn-dark"></i>
                    Under Rectification
        </div>
    </div>
    <hr>
    <br>
    <div class="row">
            <h5>Harvard</h5>
              <div class="col-md-12">
                    <p>Lower Ground Floor</p>
                    <div class="row">
                    </div>
              </div>
    </div>

</div>

</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mike\project\resources\views/rooms/show-rooms.blade.php ENDPATH**/ ?>